# COMP0004-Java-Coursework

Firstly, for the first requirement my program can store multiple notes, each which has a name and can hold text. The second requirement consists of the 
index, which my program implements – my program displays a ‘index’ of created notes, and each note can be clicked, which would then take user to the 
individual note’s page. Each note’s page allows the user to delete, rename or edit the selected note. When a note is created it is added to the index and 
removed when it is removed, notes can be created in a separate ‘Create New Note’ page. For requirement 4, the index is available to be searched, upon 
which, a list of matching notes is returned which the user can click to be taken to the notes individual page. For the final requirement the notes are 
saved when the user clicks a save button and the changes are written and loaded into the webpage.
